# VBM – Vishnu · Brahma · Mahesh
Open this folder in Android Studio -> let Gradle sync -> Build > Build APK(s).
Run the app, open the Learn tab, paste your Anthropic API key.
Chat examples:  "tell me about my phone" | "@vishnu mic" | "@brahma open wifi" | "@brahma build a to-do app"
