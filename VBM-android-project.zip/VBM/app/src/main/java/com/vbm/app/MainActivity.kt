package com.vbm.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VBM.init(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Root() } }
    }
}

private fun colorOf(n: String) = when (n) {
    "Vishnu" -> Color(0xFF64B5F6); "Brahma" -> Color(0xFFFFB74D); "Mahesh" -> Color(0xFFBA68C8); else -> Color.White }

@Composable fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar { listOf("Chat", "Learn", "Device").forEachIndexed { i, t ->
            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) }) } }
    }) { p -> Box(Modifier.padding(p).fillMaxSize()) { when (tab) { 0 -> Chat(); 1 -> Learn(); else -> Device() } } }
}

@Composable fun Chat() {
    var t by remember { mutableStateOf("") }
    val st = rememberLazyListState()
    LaunchedEffect(VBM.log.size) { if (VBM.log.isNotEmpty()) st.animateScrollToItem(VBM.log.size - 1) }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text("VBM — Vishnu · Brahma · Mahesh", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.weight(1f), state = st) {
            items(VBM.log) { m ->
                Text("${m.from} → ${m.to}\n${m.text}", Modifier.padding(vertical = 6.dp), color = colorOf(m.from))
            }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Ask… or @vishnu / @brahma") })
            Spacer(Modifier.width(6.dp))
            Button({ VBM.send(t); t = "" }) { Text("Send") }
        }
    }
}

@Composable fun Learn() {
    var key by remember { mutableStateOf(VBM.prefs.getString("key", "") ?: "") }
    var url by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { VBM.scope.launch { VBM.mahesh.importFile(it) } }
    }
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Mahesh's library: ${VBM.mahesh.k.count} chunks learned", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(key, { key = it; VBM.prefs.edit().putString("key", it).apply() },
            Modifier.fillMaxWidth(), label = { Text("Anthropic API key") })
        Button({ pick.launch(arrayOf("*/*")) }) { Text("Teach from a book / file (PDF, TXT, MD)") }
        OutlinedTextField(topic, { topic = it }, Modifier.fillMaxWidth(), label = { Text("Learn a topic online (Wikipedia)") })
        Button({ Bus.post(Msg("You", "Mahesh", "learn topic $topic")) }) { Text("Learn topic") }
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Learn from a web page URL") })
        Button({ Bus.post(Msg("You", "Mahesh", "learn url $url")) }) { Text("Learn page") }
        Text("Progress appears in the Chat tab.")
    }
}

@Composable fun Device() {
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { VBM.send("@vishnu mic") }
    fun b(label: String, cmd: String) = @Composable { Button({ VBM.send(cmd) }, Modifier.fillMaxWidth()) { Text(label) } }
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Vishnu — hardware", style = MaterialTheme.typography.titleMedium)
        b("Hardware report", "@vishnu report")()
        Button({ mic.launch(Manifest.permission.RECORD_AUDIO) }, Modifier.fillMaxWidth()) { Text("Microphone test") }
        b("Flashlight on", "@vishnu torch on")(); b("Flashlight off", "@vishnu torch off")(); b("Vibrate", "@vishnu vibrate")()
        Text("Brahma — software", style = MaterialTheme.typography.titleMedium)
        b("Software report", "@brahma report")(); b("Installed apps", "@brahma apps")(); b("Open Wi-Fi settings", "@brahma open wifi")()
        Text("Create an app: type in Chat →  @brahma build a habit tracker app", style = MaterialTheme.typography.bodySmall)
    }
}
