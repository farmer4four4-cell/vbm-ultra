package com.vbm.app

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

private val ids = AtomicLong(1)

data class Msg(
    val from: String, val to: String, val text: String,
    val id: Long = ids.getAndIncrement(), val replyTo: Long? = null
)

/** Shared channel where Vishnu, Brahma and Mahesh talk to each other and to you. */
object Bus {
    private val f = MutableSharedFlow<Msg>(extraBufferCapacity = 256)
    val flow = f.asSharedFlow()
    private val pending = ConcurrentHashMap<Long, CompletableDeferred<Msg>>()

    fun post(m: Msg) {
        f.tryEmit(m)
        m.replyTo?.let { pending.remove(it)?.complete(m) }
    }

    /** One agent asks another and waits for the answer. */
    suspend fun request(from: String, to: String, text: String, timeoutMs: Long = 15000): String? {
        val m = Msg(from, to, text)
        val d = CompletableDeferred<Msg>()
        pending[m.id] = d
        post(m)
        return withTimeoutOrNull(timeoutMs) { d.await().text }.also { pending.remove(m.id) }
    }
}

abstract class Agent(val name: String) {
    abstract suspend fun handle(m: Msg): String

    fun start() {
        VBM.scope.launch {
            Bus.flow.filter { it.to == name && it.replyTo == null }.collect { m ->
                launch {
                    val r = try { handle(m) } catch (e: Exception) { "⚠ ${e.message}" }
                    Bus.post(Msg(name, m.from, r, replyTo = m.id))
                }
            }
        }
    }
}

object VBM {
    lateinit var app: Context
    lateinit var vishnu: VishnuAgent
    lateinit var brahma: BrahmaAgent
    lateinit var mahesh: MaheshAgent
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val log = mutableStateListOf<Msg>()
    val prefs get() = app.getSharedPreferences("vbm", Context.MODE_PRIVATE)

    fun init(c: Context) {
        if (::app.isInitialized) return
        app = c.applicationContext
        CoroutineScope(Dispatchers.Main).launch { Bus.flow.collect { log.add(it) } }
        vishnu = VishnuAgent(app); brahma = BrahmaAgent(app); mahesh = MaheshAgent(app)
        listOf(vishnu, brahma, mahesh).forEach { it.start() }
        mahesh.startLifelongLearning()
    }

    /** "@vishnu ..." and "@brahma ..." go direct; everything else goes to Mahesh, who consults the others. */
    fun send(text: String) {
        val t = text.trim(); if (t.isEmpty()) return
        val body = t.substringAfter(' ', "")
        when {
            t.startsWith("@vishnu", true) -> Bus.post(Msg("You", "Vishnu", body))
            t.startsWith("@brahma", true) -> Bus.post(Msg("You", "Brahma", body))
            else -> Bus.post(Msg("You", "Mahesh", t))
        }
    }
}
