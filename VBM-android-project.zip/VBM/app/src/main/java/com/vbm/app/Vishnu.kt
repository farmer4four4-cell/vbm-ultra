package com.vbm.app

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.log10
import kotlin.math.sqrt

/** Vishnu — the preserver of the device: every hardware feature Android lets an app touch. */
class VishnuAgent(private val c: Context) : Agent("Vishnu") {

    override suspend fun handle(m: Msg): String {
        val t = m.text.lowercase()
        return when {
            "mic" in t -> micLevel()
            "torch" in t || "flash" in t -> torch("off" !in t)
            "vibrate" in t -> vibrate()
            "camera" in t -> cameras()
            "sensor" in t -> sensors()
            else -> hardwareReport()
        }
    }

    private fun gb(b: Long) = "%.1f GB".format(b / 1e9)

    fun hardwareReport(): String {
        val bm = c.getSystemService(BatteryManager::class.java)
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val st = StatFs(Environment.getDataDirectory().path)
        val dm = c.resources.displayMetrics
        return """
HARDWARE
Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.HARDWARE}, board ${Build.BOARD})
CPU ABIs: ${Build.SUPPORTED_ABIS.joinToString()}, cores: ${Runtime.getRuntime().availableProcessors()}
RAM: ${gb(mi.totalMem)} total, ${gb(mi.availMem)} free
Storage: ${gb(st.totalBytes)} total, ${gb(st.availableBytes)} free
Battery: ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, charging: ${bm.isCharging}
Display: ${dm.widthPixels}x${dm.heightPixels}px, ${dm.densityDpi} dpi
${cameras()}
${sensors()}
""".trim()
    }

    fun cameras(): String {
        val cm = c.getSystemService(CameraManager::class.java)
        return "Cameras: " + cm.cameraIdList.joinToString("; ") { id ->
            val ch = cm.getCameraCharacteristics(id)
            val face = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "front"
                CameraCharacteristics.LENS_FACING_BACK -> "back"; else -> "external" }
            val px = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
            "id$id $face ${px?.width}x${px?.height}"
        }
    }

    fun sensors(): String {
        val l = c.getSystemService(SensorManager::class.java).getSensorList(Sensor.TYPE_ALL)
        return "Sensors (${l.size}): " + l.take(15).joinToString { it.name }
    }

    private fun torch(on: Boolean): String {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flash unit found."
        cm.setTorchMode(id, on)
        return "Torch ${if (on) "ON" else "OFF"}."
    }

    private fun vibrate(): String {
        c.getSystemService(Vibrator::class.java)
            .vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
        return "Vibrated."
    }

    private suspend fun micLevel(): String = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            return@withContext "Microphone permission not granted (Device tab → Grant)."
        val rate = 44100
        val size = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
        val buf = ShortArray(size); var sum = 0.0; var n = 0
        rec.startRecording()
        val end = System.currentTimeMillis() + 1500
        while (System.currentTimeMillis() < end) {
            val r = rec.read(buf, 0, buf.size)
            for (i in 0 until r) { sum += buf[i] * buf[i].toDouble(); n++ }
        }
        rec.stop(); rec.release()
        val rms = if (n > 0) sqrt(sum / n) else 0.0
        "Mic heard ${"%.0f".format(20 * log10(rms + 1))} dB (relative level, 1.5 s sample)."
    }
}
