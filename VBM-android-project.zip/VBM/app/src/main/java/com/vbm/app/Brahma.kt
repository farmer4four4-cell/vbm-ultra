package com.vbm.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import java.io.File
import java.util.Locale
import java.util.TimeZone

/** Brahma — the creator: software state, system actions, and building new apps (as source code). */
class BrahmaAgent(private val c: Context) : Agent("Brahma") {

    override suspend fun handle(m: Msg): String {
        val t = m.text.trim(); val l = t.lowercase()
        return when {
            l.startsWith("build") -> build(t.substringAfter(' ', t))
            l.startsWith("open ") -> open(l.removePrefix("open ").trim())
            "apps" in l -> apps()
            else -> softwareReport()
        }
    }

    fun softwareReport(): String {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps == null -> "offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            else -> "connected" }
        return """
SOFTWARE
Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), security patch ${Build.VERSION.SECURITY_PATCH}
Build: ${Build.DISPLAY}
Network: $net, locale ${Locale.getDefault()}, timezone ${TimeZone.getDefault().id}
Uptime: ${SystemClock.elapsedRealtime() / 3600000} h
${apps()}
""".trim()
    }

    private fun userApps() = c.packageManager.getInstalledApplications(0)
        .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
        .map { c.packageManager.getApplicationLabel(it).toString() to it.packageName }
        .sortedBy { it.first.lowercase() }

    fun apps(): String {
        val a = userApps()
        return "Installed user apps (${a.size}): " + a.take(40).joinToString { it.first }
    }

    private fun open(what: String): String {
        val settings = mapOf(
            "settings" to Settings.ACTION_SETTINGS, "wifi" to Settings.ACTION_WIFI_SETTINGS,
            "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS, "display" to Settings.ACTION_DISPLAY_SETTINGS,
            "battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        settings.entries.firstOrNull { it.key in what }?.let {
            c.startActivity(Intent(it.value).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Opened ${it.key} settings."
        }
        val hit = userApps().firstOrNull { what in it.first.lowercase() } ?: return "No app matching '$what'."
        val i = c.packageManager.getLaunchIntentForPackage(hit.second) ?: return "${hit.first} has no launcher."
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Opened ${hit.first}."
    }

    /** Brahma asks Mahesh what he has learned, then has the LLM write a project and saves it. */
    private suspend fun build(spec: String): String {
        val know = Bus.request("Brahma", "Mahesh", "recall $spec") ?: ""
        val code = Llm.ask(
            "You are Brahma, the creator. Write a complete, working Android (Kotlin + Jetpack Compose) project for the request. " +
                "Output every file as: ===FILE: relative/path=== followed by its full contents. No commentary.",
            "Request: $spec\n\nRelevant knowledge Mahesh has learned:\n$know", 6000)
        val dir = File(c.getExternalFilesDir(null), "generated").apply { mkdirs() }
        val f = File(dir, "app_${System.currentTimeMillis()}.txt").apply { writeText(code) }
        return "Built. Saved to ${f.absolutePath}\n\n" + code.take(600) + "…"
    }
}
