package com.vbm.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Llm {
    const val MODEL = "claude-sonnet-4-6"

    suspend fun ask(system: String, user: String, maxTokens: Int = 2000): String = withContext(Dispatchers.IO) {
        val key = VBM.prefs.getString("key", "") ?: ""
        if (key.isBlank()) return@withContext "Add your Anthropic API key in the Learn tab first."
        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", maxTokens).put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 90000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val resp = stream.bufferedReader().readText()
        if (c.responseCode !in 200..299) return@withContext "API error ${c.responseCode}: $resp"
        val arr = JSONObject(resp).getJSONArray("content")
        buildString { for (i in 0 until arr.length()) arr.getJSONObject(i).optString("text").let { append(it) } }
    }
}
