package com.vbm.app

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Offline memory: chunks saved on the phone, searched by keyword score. */
class Knowledge(ctx: Context) {
    private val file = File(ctx.filesDir, "knowledge.jsonl")
    private val items = mutableListOf<Pair<String, String>>() // source, text
    var count by mutableIntStateOf(0)

    init {
        if (file.exists()) file.forEachLine { runCatching { JSONObject(it) }.getOrNull()?.let { j -> items.add(j.getString("s") to j.getString("t")) } }
        count = items.size
    }

    @Synchronized fun add(source: String, text: String) {
        text.trim().chunked(800).filter { it.isNotBlank() }.forEach {
            items.add(source to it)
            file.appendText(JSONObject().put("s", source).put("t", it).toString() + "\n")
        }
        count = items.size
    }

    /** Replace everything from one source (used for fresh device snapshots). */
    @Synchronized fun replace(source: String, text: String) {
        items.removeAll { it.first == source }
        file.writeText(items.joinToString("") { JSONObject().put("s", it.first).put("t", it.second).toString() + "\n" })
        add(source, text)
    }

    @Synchronized fun search(q: String, k: Int = 5): List<Pair<String, String>> {
        val words = q.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.distinct()
        return items.map { it to words.sumOf { w -> Regex(Regex.escape(w)).findAll(it.second.lowercase()).count() } }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(k).map { it.first }
    }
}

/** Mahesh — the learner. Reads your files, the web, and the phone itself, and answers from all three. */
class MaheshAgent(private val c: Context) : Agent("Mahesh") {
    val k = Knowledge(c)

    override suspend fun handle(m: Msg): String {
        val t = m.text.trim(); val l = t.lowercase()
        return when {
            l.startsWith("recall ") -> k.search(t.removePrefix("recall ")).joinToString("\n---\n") { it.second }
            l.startsWith("learn url ") -> learnUrl(t.removePrefix("learn url ").trim())
            l.startsWith("learn topic ") -> learnWiki(t.removePrefix("learn topic ").trim())
            else -> answer(t)
        }
    }

    private suspend fun answer(q: String): String {
        val deviceWords = listOf("phone", "mobile", "device", "battery", "camera", "app", "storage", "sensor", "ram", "android", "screen")
        if (deviceWords.any { it in q.lowercase() }) snapshotDevice()
        var hits = k.search(q)
        if (hits.size < 2) { learnWiki(q); hits = k.search(q) } // doesn't know → learns online
        val ctx = hits.joinToString("\n---\n") { "[${it.first}]\n${it.second}" }
        return Llm.ask(
            "You are Mahesh, the learning mind of VBM, working with Vishnu (hardware) and Brahma (software). " +
                "Answer using the knowledge below when relevant and mention the source. Be clear and practical.",
            "Question: $q\n\nKnowledge:\n$ctx")
    }

    /** Mahesh asks his two brothers about the phone and memorises the answers. */
    suspend fun snapshotDevice() {
        Bus.request("Mahesh", "Vishnu", "hardware report")?.let { k.replace("device:hardware", it) }
        Bus.request("Mahesh", "Brahma", "software report")?.let { k.replace("device:software", it) }
    }

    fun startLifelongLearning() {
        VBM.scope.launch { while (true) { runCatching { snapshotDevice() }; delay(15 * 60 * 1000L) } }
    }

    suspend fun importFile(uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            val type = c.contentResolver.getType(uri) ?: ""
            val name = uri.lastPathSegment ?: "file"
            val text = c.contentResolver.openInputStream(uri)!!.use { s ->
                if (type.contains("pdf") || name.endsWith(".pdf", true)) {
                    PDFBoxResourceLoader.init(c)
                    PDDocument.load(s).use { PDFTextStripper().getText(it) }
                } else s.bufferedReader().readText()
            }
            k.add("file:$name", text)
            say("Learned '$name' (${text.length} characters). Memory: ${k.count} chunks.")
        } catch (e: Exception) { say("Could not read file: ${e.message}") }
    }

    private suspend fun learnUrl(u: String): String = withContext(Dispatchers.IO) {
        val html = get(u)
        val text = html.replace(Regex("(?is)<(script|style).*?</\\1>"), " ").replace(Regex("<[^>]+>"), " ")
            .replace(Regex("\\s+"), " ")
        k.add("web:$u", text.take(40000)); "Learned from $u (${text.length} chars)."
    }

    private suspend fun learnWiki(q: String): String = withContext(Dispatchers.IO) {
        try {
            val e = URLEncoder.encode(q.take(100), "UTF-8")
            val hit = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch=$e"))
                .getJSONObject("query").getJSONArray("search")
            if (hit.length() == 0) return@withContext "Nothing found online for '$q'."
            val title = hit.getJSONObject(0).getString("title")
            val pages = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&redirects=1&format=json&titles=" +
                URLEncoder.encode(title, "UTF-8"))).getJSONObject("query").getJSONObject("pages")
            val text = pages.getJSONObject(pages.keys().next()).optString("extract")
            k.add("web:wikipedia:$title", text.take(30000)); "Learned '$title' from Wikipedia."
        } catch (e: Exception) { "Online learning failed: ${e.message}" }
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.setRequestProperty("User-Agent", "VBM/1.0")
        return c.inputStream.bufferedReader().use { it.readText() }.take(600_000)
    }

    private fun say(t: String): String { Bus.post(Msg("Mahesh", "You", t)); return t }
}
